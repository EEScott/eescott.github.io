# Hawaii Trip Blog
This is a casual travel blog documenting our adventures in Hawaii.